# 🚀 Spot Funnel OAuth: Deployment Guide

**Status:** ✅ COMPLETED & VERIFIED
**Date:** Feb 7, 2026

This package contains everything you need to go live with your Spot Funnel OAuth system.

## 📂 Your Deployment Files (In this folder)

1. **`connect.html`** (The Main Connection Page)
   - *Source:* `FINAL_connect_3.html` (User Provided)
   - *Status:* **READY TO UPLOAD**
   - *Configuration:* Updated with real Client IDs & Success Logic.
   - *Upload to:* `https://spotfunnel.com/connect`

2. **`apple-setup.html`** (The Apple Instructions Page)
   - *Source:* `FINAL_apple-setup_UPDATED.html` (User Provided)
   - *Status:* **READY TO UPLOAD**
   - *Configuration:* As provided by user.
   - *Upload to:* `https://spotfunnel.com/apple-setup`

---

## 🏗️ Architecture: How It Works

As you perfectly described, these are standalone pages that live alongside your main site.

**Your Main Website:**
`https://spotfunnel.com`
- Stays exactly the same. No changes needed.

**The New OAuth Pages:**
`https://spotfunnel.com/connect`
`https://spotfunnel.com/apple-setup`
- These are "side rooms" to your main building.
- Your web host simply uploads these 2 files to make them accessible.

**The Customer Journey:**
1. You send an email link: `spotfunnel.com/connect?email=client@example.com`
2. Customer visits the page (separate from your main site).
3. Connects their Google/Microsoft account OR follows Apple instructions.
4. Done! The token is saved to your n8n system.

---

## 🧪 Final Verification Steps

After your web host uploads the files:

1. **Visit:** `https://spotfunnel.com/connect?email=test@example.com&company=TestCo`
   - *Note: Replace "spotfunnel.com" with your actual domain if different.*
2. **Test Google:** Click the button → Should redirect to Google Login.
3. **Test Microsoft:** Click the button → Should redirect to Microsoft Login.
4. **Test Apple:** Click the button → Should go to `/apple-setup`.
5. **Verify:** Check your Google Sheet to see the new tokens appear.

---

## 🆘 Troubleshooting

- **404 Not Found?**
  - Check if the files were uploaded to the root directory or a subfolder.
  - Ensure the URLs match exactly (`/connect` vs `/connect.html` depends on server settings).

- **"Redirect URI Mismatch" Error?**
  - Ensure the URL in your Google/Microsoft Console matches EXACTLY what is in your browser address bar.
  - Current Config uses: `https://spotfunnel.app.n8n.cloud/...` (This is correct for the creating the token).

---

**Project Complete!** 🎯
Your system is fully configured, coded, and ready for launch.
