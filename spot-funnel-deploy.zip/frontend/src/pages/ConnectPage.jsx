import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Calendar, Settings, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';

export default function ConnectPage() {
    const [selection, setSelection] = useState(null);
    const [status, setStatus] = useState('idle'); // idle | authorizing | success | error
    const [step, setStep] = useState(1); // 1 = Email, 2 = Calendar

    const handleConnect = async () => {
        // Construct the OAuth URL to redirect to n8n
        // We direct the user to Google's OAuth 2.0 endpoint.
        // The redirect_uri is set to our n8n webhook, which will receive the code.
        const n8nWebhook = "https://spotfunnel.app.n8n.cloud/webhook/google-oauth-callback";
        const clientId = "795418246463-bfh03g04tkgpletq92dj5n541qaeconf.apps.googleusercontent.com"; // From n8n-oauth-workflow-v2.json

        // We add 'gmail.modify' and 'calendar.events' scopes as per the project requirements
        const scope = encodeURIComponent("https://www.googleapis.com/auth/gmail.modify https://www.googleapis.com/auth/calendar.events");

        // We pass state to n8n so it knows what the user selected (e.g. 'email', 'same', 'different')
        // Format: email|type (e.g. user_placeholder|email-only)
        const state = encodeURIComponent(`user_placeholder|${selection}`);

        const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${n8nWebhook}&response_type=code&scope=${encodedScope}&state=${state}&access_type=offline&prompt=consent`;

        // Handle 2-step flow for 'Different Accounts'
        if (selection === 'different' && step === 1) {
            setStatus('authorizing');
            // For 'different', step 1 is email. We'll use the same OAuth URL for now,
            // but normally we might want to flag this as specifically the 'email' step in state.
            // Let's redirect them.
            window.location.href = authUrl;
            return;
        }

        setStatus('authorizing');
        // For other selections (email, same), redirect immediately
        window.location.href = authUrl;
    };

    const getButtonText = () => {
        if (status === 'authorizing') return 'Redirecting...';
        if (status === 'success') return 'Connected!';
        if (status === 'error') return 'Retry Connection';

        if (selection === 'different') {
            return step === 1 ? 'Connect Email Account' : 'Connect Calendar Account';
        }
        return 'Connect with Google';
    };

    const getHelperText = () => {
        if (selection === 'different') {
            if (step === 1) return 'Step 1 of 2: Connect your Email provider first.';
            return 'Step 2 of 2: Now connect your Calendar provider.';
        }
        return 'You will be redirected to Google to authorize access.';
    };

    return (
        <div className="min-h-screen bg-[#F3F4F7] flex flex-col items-center justify-center p-6 font-sans text-[#0F1729]">

            {/* Main Container "Box" - Updated shadow and border radius to match site */}
            <div className="w-full max-w-5xl bg-white rounded-3xl shadow-lifted border border-[#E1E7EF] overflow-hidden relative">

                {/* Subtle top decorative line (optional, kept from before but refined) */}
                <div className="h-1.5 w-full bg-gradient-to-r from-[#1DAFA1] to-[#F59F0A]"></div>

                <div className="p-8 md:p-16">
                    {/* Header */}
                    <div className="text-center max-w-2xl mx-auto mb-16">
                        <div className="inline-flex items-center justify-center w-16 h-16 bg-[#1DAFA1]/10 rounded-2xl mb-6">
                            <svg viewBox="0 0 24 24" className="w-8 h-8 text-[#1DAFA1]" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                            </svg>
                        </div>
                        <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-[#0F1729] mb-4">
                            Connect Your Accounts
                        </h1>
                        <p className="text-lg text-slate-500">
                            Grant SpotFunnel access to manage your schedule and communications.
                        </p>
                    </div>

                    {/* Selection Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">

                        {/* Option 1: Email Only */}
                        <Card
                            isSelected={selection === 'email'}
                            onClick={() => { setSelection('email'); setStep(1); }}
                            className="group h-full"
                        >
                            <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                                <Mail className="w-7 h-7" />
                            </div>
                            <h3 className="text-xl font-bold text-[#0F1729] mb-3">Email Only</h3>
                            <p className="text-sm text-slate-500 leading-relaxed">
                                Connect your Gmail to allow sending and reading emails on your behalf.
                            </p>
                        </Card>

                        {/* Option 2: Same Email & Calendar */}
                        <Card
                            isSelected={selection === 'same'}
                            onClick={() => { setSelection('same'); setStep(1); }}
                            className="group h-full"
                        >
                            <div className="w-14 h-14 rounded-2xl bg-[#1DAFA1]/10 text-[#1DAFA1] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                                <div className="flex -space-x-1">
                                    <Mail className="w-6 h-6" />
                                    <Calendar className="w-6 h-6" />
                                </div>
                            </div>
                            <h3 className="text-xl font-bold text-[#0F1729] mb-3">Same Account</h3>
                            <p className="text-sm text-slate-500 leading-relaxed">
                                Connect both Email and Calendar from the <strong>same</strong> Google account.
                            </p>
                            {selection === 'same' && (
                                <div className="absolute top-5 right-5 text-[#1DAFA1]">
                                    <CheckCircle2 className="w-6 h-6 fill-[#1DAFA1]/10" />
                                </div>
                            )}
                        </Card>

                        {/* Option 3: Different Email & Calendar */}
                        <Card
                            isSelected={selection === 'different'}
                            onClick={() => { setSelection('different'); setStep(1); }}
                            className="group h-full"
                        >
                            <div className="w-14 h-14 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                                <Settings className="w-7 h-7" />
                            </div>
                            <h3 className="text-xl font-bold text-[#0F1729] mb-3">Different Accounts</h3>
                            <p className="text-sm text-slate-500 leading-relaxed">
                                Connect Email and Calendar from <strong>two separate</strong> Google accounts.
                            </p>
                            {selection === 'different' && step === 2 && (
                                <div className="absolute top-5 right-5 bg-purple-100 text-purple-700 text-xs font-bold px-2.5 py-1 rounded-full">
                                    Step 2
                                </div>
                            )}
                        </Card>
                    </div>

                    {/* Footer / Connect Action */}
                    <AnimatePresence mode="wait">
                        {selection && (
                            <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: 10 }}
                                className="flex justify-center"
                            >
                                {status === 'success' ? (
                                    <motion.div
                                        initial={{ scale: 0.95 }}
                                        animate={{ scale: 1 }}
                                        className="bg-emerald-50 text-emerald-800 px-8 py-6 rounded-2xl flex items-center gap-4 border border-emerald-100 w-full max-w-xl shadow-sm"
                                    >
                                        <div className="bg-emerald-100 p-2.5 rounded-full text-emerald-600">
                                            <CheckCircle2 className="w-6 h-6" />
                                        </div>
                                        <div>
                                            <p className="font-bold text-lg mb-0.5">Successfully Connected!</p>
                                            <p className="text-sm opacity-80">Your account is ready to go.</p>
                                        </div>
                                    </motion.div>
                                ) : (
                                    <div className="text-center w-full max-w-md">
                                        <Button
                                            size="lg"
                                            className="w-full text-lg py-4 mb-4 shadow hover:shadow-lg transition-shadow"
                                            onClick={handleConnect}
                                            isLoading={status === 'authorizing'}
                                        >
                                            {getButtonText()}
                                            {!status.includes('authorizing') && <ArrowRight className="ml-2 w-5 h-5" />}
                                        </Button>
                                        <p className="text-sm text-slate-400 font-medium">
                                            {status === 'authorizing' ? 'Securely redirecting to Google...' : getHelperText()}
                                        </p>
                                    </div>
                                )}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </div>

            {/* Brand Footer */}
            <div className="mt-8 text-slate-400 text-sm font-medium">
                Powered by SpotFunnel &bull; Secure Connection
            </div>
        </div>
    );
}
