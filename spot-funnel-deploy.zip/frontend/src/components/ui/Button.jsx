import React from 'react';
import { Loader2 } from 'lucide-react';

export function Button({
    children,
    variant = 'primary',
    className = '',
    isLoading = false,
    ...props
}) {
    const baseStyles = "inline-flex items-center justify-center px-6 py-3 rounded-xl font-bold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#1DAFA1]/20";

    const variants = {
        primary: "bg-[#1DAFA1] text-white hover:bg-[#189693] shadow-lg shadow-[#1DAFA1]/30 hover:shadow-xl hover:shadow-[#1DAFA1]/40 active:scale-95",
        secondary: "bg-white text-[#0F1729] border border-[#E1E7EF] hover:border-[#CBD5E1] hover:bg-[#F8FAFC]",
        outline: "bg-transparent border-2 border-[#1DAFA1] text-[#1DAFA1] hover:bg-[#1DAFA1]/5",
        ghost: "bg-transparent text-slate-600 hover:bg-slate-100",
        success: "bg-emerald-500 text-white hover:bg-emerald-600 shadow-lg shadow-emerald-500/20 cursor-default",
    };

    return (
        <button
            className={`${baseStyles} ${variants[variant]} ${className}`}
            disabled={isLoading || props.disabled}
            {...props}
        >
            {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            {children}
        </button>
    );
}
