import React from 'react';
import { motion } from 'framer-motion';

export function Card({ children, className = '', onClick, isSelected, ...props }) {
    return (
        <motion.div
            onClick={onClick}
            className={`
        relative overflow-hidden rounded-2xl p-8 border-2 transition-all duration-300 cursor-pointer bg-white
        ${isSelected
                    ? 'border-[#1DAFA1] shadow-lg ring-4 ring-[#1DAFA1]/5 translate-y-[-4px]'
                    : 'border-[#E1E7EF] hover:border-[#CBD5E1] hover:shadow-xl hover:translate-y-[-4px]'
                }
        ${className}
      `}
            whileTap={{ scale: 0.98 }}
            {...props}
        >
            {isSelected && (
                <div className="absolute inset-0 bg-gradient-to-tr from-[#1DAFA1]/5 to-transparent pointer-events-none" />
            )}
            {children}
        </motion.div>
    );
}
