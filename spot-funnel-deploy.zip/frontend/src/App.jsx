import React from 'react';
import ConnectPage from './pages/ConnectPage';

function App() {
  return (
    <div className="App min-h-screen bg-[#F8FAFC] text-slate-900 flex items-center justify-center">
      <ConnectPage />
    </div>
  );
}

export default App;
