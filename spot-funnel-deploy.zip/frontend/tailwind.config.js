/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Inter', 'system-ui', 'sans-serif'],
            },
            colors: {
                brand: {
                    teal: '#1DAFA1',  // Updated from #1DAFAB to match site
                    navy: '#0F1729',  // Deep navy for text
                    bg: '#F3F4F7',    // Site background
                    border: '#E1E7EF', // Subtle border
                }
            },
            backgroundImage: {
                'hero-gradient': 'radial-gradient(circle at 50% 0%, rgba(29, 175, 161, 0.08) 0%, rgba(255, 255, 255, 0) 50%)',
                'text-gradient': 'linear-gradient(to right, #1DAFA1, #F59F0A)',
            },
            boxShadow: {
                'lifted': '0 10px 40px -10px rgba(0,0,0,0.08)', // Smooth, large shadow for main box
                'card': '0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)',
            }
        },
    },
    plugins: [],
}
