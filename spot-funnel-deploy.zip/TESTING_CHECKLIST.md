# Spot Funnel Testing Checklist 🧪

Use this guide to verify your entire setup before going live.

## 📦 File Check
- [ ] `connect.html` is uploaded to your website (e.g., `yourdomain.com/connect`)
- [ ] `apple-setup.html` is uploaded to your website (e.g., `yourdomain.com/apple-setup`)
- [ ] `connect.html` has your **REAL** Client IDs (not placeholders)

## 🌐 1. Google Integration Test
1. **Visit Page**: Go to your live `connect.html` page.
2. **Input Data**: Enter a test email (e.g., `test.google@example.com`) and Company Name.
3. **Click Button**: Click "Connect Google".
4. **Auth Flow**:
   - [ ] Redirects to Google Sign-in?
   - [ ] Asks for permissions (Calendar/Gmail)?
   - [ ] Redirects back to success page ("Calendar Connected!")?
5. **Verify Data**:
   - [ ] Check Google Sheet: New row with `provider: google`?
   - [ ] Check Admin Email: Did you get a notification?

## 🟦 2. Microsoft Integration Test
1. **Visit Page**: Refresh `connect.html`.
2. **Input Data**: Enter a test email (e.g., `test.microsoft@example.com`) and Company Name.
3. **Click Button**: Click "Connect Microsoft".
4. **Auth Flow**:
   - [ ] Redirects to Microsoft Sign-in?
   - [ ] Asks for permissions?
   - [ ] Redirects back to success page?
5. **Verify Data**:
   - [ ] Check Google Sheet: New row with `provider: microsoft`?
   - [ ] Check Admin Email: Did you get a notification?

## 🍎 3. Apple Integration Test
1. **Visit Page**: Refresh `connect.html`.
2. **Click Button**: Click "Connect Apple".
3. **Flow**:
   - [ ] Redirects to `apple-setup.html`?
4. **Follow Steps**:
   - [ ] Apple ID link works?
   - [ ] Form takes email & password?
   - [ ] "Send" button opens your default email client?
   - [ ] Email body is pre-filled correctly?

## 🚨 Troubleshooting
- **400 Error (Redirect URI mismatch)**:
  - Check n8n webhook URL matches exactly what is in Google/Microsoft console.
  - Ensure `https` is used everywhere.
- **403 Error (Forbidden)**:
  - Check Google Sheet permissions (shared with n8n service account email).
- **Buttons don't click**:
  - Open Console (F12) and check for JavaScript errors.
  - Ensure `CONFIG` object in `connect.html` has valid IDs.
