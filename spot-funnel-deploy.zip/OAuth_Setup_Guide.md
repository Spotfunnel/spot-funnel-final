# Spot Funnel OAuth Setup Guide
## One-Time Setup for Calendar + Email Access

This guide will help you create OAuth apps that allow customers to authorize Spot Funnel to access their calendars and emails with just one click.

---

## Part 1: Google OAuth App Setup (Gmail + Google Calendar)

### Step 1: Create Google Cloud Project

1. Go to: https://console.cloud.google.com
2. Sign in with your Google account
3. Click the project dropdown at the top
4. Click **"New Project"**
5. Name it: **"Spot Funnel OAuth"**
6. Click **"Create"**

### Step 2: Enable APIs

1. In the search bar, type: **"Google Calendar API"**
2. Click on it and click **"Enable"**
3. Go back and search: **"Gmail API"**
4. Click on it and click **"Enable"**

### Step 3: Configure OAuth Consent Screen

1. In the left menu, click **"APIs & Services"** → **"OAuth consent screen"**
2. Choose **"External"**
3. Click **"Create"**
4. Fill in:
   - App name: **"Spot Funnel"**
   - User support email: **your email**
   - Developer contact: **your email**
5. Click **"Save and Continue"**

6. **Add Scopes** (Click "Add or Remove Scopes"):
   - Search and add these scopes:
     - `https://www.googleapis.com/auth/calendar` (Google Calendar access)
     - `https://www.googleapis.com/auth/gmail.send` (Send emails)
     - `https://www.googleapis.com/auth/gmail.readonly` (Read emails)
7. Click **"Update"**
8. Click **"Save and Continue"**

9. **Add Test Users**:
   - Click **"Add Users"**
   - Add your email (for testing)
   - Click **"Save and Continue"**

10. Click **"Back to Dashboard"**

### Step 4: Create OAuth Credentials

1. Click **"Credentials"** in the left menu
2. Click **"Create Credentials"** → **"OAuth client ID"**
3. Application type: **"Web application"**
4. Name: **"Spot Funnel Web Client"**
5. **Authorized redirect URIs** - Add:
   - `https://YOUR-N8N-DOMAIN/webhook/google-oauth-callback`
   - (Replace YOUR-N8N-DOMAIN with your actual n8n URL)
   - Example: `https://n8n.spotfunnel.com/webhook/google-oauth-callback`
6. Click **"Create"**

### Step 5: Save Your Credentials

You'll see a popup with:
- **Client ID** (looks like: `123456789-abc123.apps.googleusercontent.com`)
- **Client Secret** (looks like: `GOCSPX-abc123xyz`)

**SAVE THESE!** You'll need them for n8n.

---

## Part 2: Microsoft OAuth App Setup (Outlook + Calendar)

### Step 1: Go to Azure Portal

1. Go to: https://portal.azure.com
2. Sign in with your Microsoft account
3. Search for: **"App registrations"**
4. Click on it

### Step 2: Register New App

1. Click **"+ New registration"**
2. Name: **"Spot Funnel OAuth"**
3. Supported account types: **"Accounts in any organizational directory and personal Microsoft accounts"**
4. Redirect URI:
   - Platform: **"Web"**
   - URL: `https://YOUR-N8N-DOMAIN/webhook/microsoft-oauth-callback`
   - (Replace YOUR-N8N-DOMAIN with your actual n8n URL)
5. Click **"Register"**

### Step 3: Save Application Details

On the Overview page, copy and save:
- **Application (client) ID**
- **Directory (tenant) ID**

### Step 4: Create Client Secret

1. Click **"Certificates & secrets"** in the left menu
2. Click **"+ New client secret"**
3. Description: **"Spot Funnel Secret"**
4. Expires: **"24 months"**
5. Click **"Add"**
6. **IMMEDIATELY copy the "Value"** - you won't see it again!

### Step 5: Set API Permissions

1. Click **"API permissions"** in the left menu
2. Click **"+ Add a permission"**
3. Select **"Microsoft Graph"**
4. Choose **"Delegated permissions"**
5. Add these permissions:
   - **Calendars.ReadWrite** (Read and write calendars)
   - **Mail.Send** (Send emails)
   - **Mail.Read** (Read emails)
6. Click **"Add permissions"**
7. Click **"Grant admin consent for..."** and confirm

---

## Part 3: What You Have Now

### Google Credentials:
- ✅ Client ID
- ✅ Client Secret
- ✅ Redirect URI: `https://YOUR-N8N-DOMAIN/webhook/google-oauth-callback`

### Microsoft Credentials:
- ✅ Client ID
- ✅ Client Secret  
- ✅ Tenant ID
- ✅ Redirect URI: `https://YOUR-N8N-DOMAIN/webhook/microsoft-oauth-callback`

---

## Next Steps:

1. ✅ Import the n8n workflow (see n8n-oauth-workflow.json)
2. ✅ Add your credentials to the workflow
3. ✅ Deploy the connect.html page to your website
4. ✅ Test with your own account first
5. ✅ Share the link with customers!

---

## Notes:

- **Google App is in "Testing" mode**: Only test users can authorize. When ready for production, you'll need to verify the app (or keep adding users manually).
- **Microsoft App**: Works immediately for all users
- **Tokens expire**: The workflow handles automatic refresh
- **Security**: Tokens are stored securely in your n8n database/Google Sheets

---

## Troubleshooting:

**"Access blocked" error:**
- Make sure you added your email as a test user in Google

**"Redirect URI mismatch":**
- Double-check your n8n webhook URL matches exactly

**"Invalid scope":**
- Make sure you added all the scopes listed above

---

Need help? Reply to your onboarding email!
