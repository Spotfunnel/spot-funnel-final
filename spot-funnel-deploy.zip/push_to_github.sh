#!/bin/bash
echo "🚀 Pushing to GitHub..."

# Check if origin exists
if git remote get-url origin > /dev/null 2>&1; then
    echo "Using existing remote: $(git remote get-url origin)"
else
    echo "❌ No remote repository found!"
    echo "Please set a remote first: git remote add origin <URL>"
    exit 1
fi

# Push
try_push() {
    git push -u origin main
}

if try_push; then
    echo "✅ Successfully pushed to GitHub!"
else
    echo "⚠️  Push failed. You may need to log in above."
    echo "If you saw a password prompt, try again."
fi
